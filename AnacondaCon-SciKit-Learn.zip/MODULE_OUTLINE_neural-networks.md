## Neural Networks and Deep Learning (1/2 day)

* Neural nets as classifiers
* Perceptrons
* Convolutional neural networks
* Long short-term memory networks