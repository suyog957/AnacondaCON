## Rendering nice images / styles to highlite things

Images for navigation selected from open license icons can be found [here](http://sourceforge.net/projects/openiconlibrary/files/0.11/open_icon_library-standard-0.11.tar.bz2/download)

## Here's a nice way to render just the image, usually left-aligned is good. Replace the src with "img/topics/....."

<img src="Essential-Concept.png" align='left'/>
This topic is something basic that you should definitely learn.  Some more details about the concept include blah, foo, bar, and spam.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

## Here's a nice way to render back-ground color
<span style="background-color:#F8F8E8">
<img src="Essential-Concept.png" align='left'/>
This topic is something basic that you should definitely learn.  Some more details about the concept include blah, foo, bar, and spam.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
</span>
